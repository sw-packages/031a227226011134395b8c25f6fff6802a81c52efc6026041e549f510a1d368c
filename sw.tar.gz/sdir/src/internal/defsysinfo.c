#include "libc.h"

size_t __sysinfo;
