#include <shadow.h>

int lckpwdf()
{
	return 0;
}

int ulckpwdf()
{
	return 0;
}
