#include <math.h>

float nanf(const char *s)
{
	return NAN;
}
